import React from "react";

const AvarageHoldTime = () => {
  return <div>Avarage Hold Time</div>;
};

export default AvarageHoldTime;
