import React from "react";

const CallVolume = () => {
  return <div>Call Volume</div>;
};

export default CallVolume;
