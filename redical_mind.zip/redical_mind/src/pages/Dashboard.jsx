import React from "react";
import UserTable from "../Table/UserTable";

const Dashboard = () => {
  return (
    <div>
      <UserTable />
    </div>
  );
};

export default Dashboard;
