import React from "react";

const Occupancy = () => {
  return <div>Occupancy</div>;
};

export default Occupancy;
