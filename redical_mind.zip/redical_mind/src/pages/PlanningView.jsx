import React from "react";

const PlanningView = () => {
  return <div>Plannig View</div>;
};

export default PlanningView;
