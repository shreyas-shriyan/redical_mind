const styles = (theme) => {
  return {
    container: {
      padding: theme.spacing(2),
    },
  };
};

export default styles;
