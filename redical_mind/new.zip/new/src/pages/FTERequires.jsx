import React from "react";

const FTERequires = () => {
  return <div>FTE Requires</div>;
};

export default FTERequires;
