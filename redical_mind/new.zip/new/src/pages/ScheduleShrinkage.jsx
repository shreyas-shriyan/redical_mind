import React from "react";

const ScheduleShrinkage = () => {
  return <div>Schedule Shrinkage</div>;
};

export default ScheduleShrinkage;
