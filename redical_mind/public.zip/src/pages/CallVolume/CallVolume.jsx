import React from "react";

const CallVolume = () => {
  return <div>CallVolume</div>;
};

export default CallVolume;
