import React from "react";

const HeadCount = () => {
  return <div>Head Count</div>;
};

export default HeadCount;
